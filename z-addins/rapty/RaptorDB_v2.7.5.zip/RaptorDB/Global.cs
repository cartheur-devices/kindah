﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RaptorDB
{
    public class Global
    {
        public static int BitmapOffsetSwitchOverCount = 10;

        public static ushort PageItemCount = 10000;

        public static int SaveIndexToDiskTimerSeconds = 3000;

        public static byte DefaultStringKeySize = 60;

        public static bool FlushStorageFileImmetiatley = false;

        public static bool FreeBitmapMemoryOnSave = false;
    }
}
