using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // Get the file that contains the rules
            string fileFullPath = "InsPolicyA.rule";  // put the full path here
            if (System.IO.File.Exists(fileFullPath) == false)
            {
                Console.WriteLine("Cannot find the file '" + fileFullPath + ".  Please modify the source code to include the full path.");
                Console.WriteLine("\n\n\nPress [Enter] to exit");
                Console.ReadLine();
                return;
            }

            // create a FileInfo object
            System.IO.FileInfo file = new System.IO.FileInfo(fileFullPath);

            // create a token object from the file
            Console.WriteLine("Creating the tokens from the .Rule file:");
            Console.WriteLine("============================================");

            EvaluationEngine.Parser.Token token = null;
            try
            {
                token = new EvaluationEngine.Parser.Token(file);
            }
            catch (Exception err)
            {
                Console.WriteLine("Failed to load the rule: " + err.Message);
                Console.WriteLine("\n\n\nPress [Enter] to exit");
                Console.ReadLine();
                return;
            }
           
            // see if we got an erro
            if (token.AnyErrors == true)
            {
                Console.WriteLine("Error while loading and parsing the tokens: " + token.LastErrorMessage);
                Console.WriteLine("\n\n\nPress [Enter] to exit");
                Console.ReadLine();
                return;
            }

            // create the evaluator object
            EvaluationEngine.Evaluate.Evaluator eval = new EvaluationEngine.Evaluate.Evaluator(token);

            Console.WriteLine("Token Parse Time: " + token.TokenParseTime.ToString() + " ms");




            Console.WriteLine("\nEvaluation 1:");
            Console.WriteLine("============================================");
            EvaluateRule(token, eval, "38", "false", "175");

            Console.WriteLine("\nEvaluation 2:");
            Console.WriteLine("============================================");
            EvaluateRule(token, eval, "56", "true", "220");

            Console.WriteLine("\n\nPress [Enter] to exit");
            Console.ReadLine();
            
           
        }

        static void temp()
        {
            // create the token object from the .Rule file
            EvaluationEngine.Parser.Token token = new EvaluationEngine.Parser.Token(new System.IO.FileInfo("InsPolicyA.rule"));

            // set the values for the variables
            token.Variables["Age"].VariableValue = "38";
            token.Variables["Smoker"].VariableValue = "false";
            token.Variables["Weight"].VariableValue = "175";

            // create the evaluator object and pass in the token object in the constructor
            EvaluationEngine.Evaluate.Evaluator eval = new EvaluationEngine.Evaluate.Evaluator(token);

            // run the evaluation
            string ErrorMsg = "";
            string result = "";
            if (eval.Evaluate(out result, out ErrorMsg) == true)
            {
                Console.WriteLine(result);
            }

        }


        public static void EvaluateRule(EvaluationEngine.Parser.Token token, EvaluationEngine.Evaluate.Evaluator eval, string Age, string Smoker, string Weight)
        {
            // set the variables
            token.Variables["Age"].VariableValue = Age;
            token.Variables["Smoker"].VariableValue = Smoker;
            token.Variables["Weight"].VariableValue = Weight;


            string ErrorMsg = "";
            string result = "";
            if (eval.Evaluate(out result, out ErrorMsg) == false)
            {
                Console.WriteLine("Error evaluating the tokens: " + ErrorMsg);
            }
            else
            {
                Console.WriteLine("Parameters:");
                Console.WriteLine("Age = " + Age);
                Console.WriteLine("Smoker = " + Smoker);
                Console.WriteLine("Weight = " + Weight);
                Console.Write("Result = ");
                Console.WriteLine(result);
                Console.WriteLine("Evaluation Time: " + eval.TokenEvalTime.ToString() + " ms");

            }
        }
    }
}
