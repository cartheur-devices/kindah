using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RulesCalculator
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }


        private void frmMain_Load(object sender, EventArgs e)
        {

            try
            {
                if (System.IO.Directory.Exists(ExpressionDirectory) == false)
                {
                    System.IO.Directory.CreateDirectory(ExpressionDirectory);
                }
            }
            catch { }

            tabControl1_SelectedIndexChanged(sender, e);

        }

        public string ExpressionDirectory
        {
            get
            {
                // see if the save folder exists
                string currentDir = System.Environment.CurrentDirectory;

                string saveDir = "";
                if (currentDir.EndsWith("\\") == true)
                    saveDir = currentDir + "Expressions\\";
                else
                    saveDir = currentDir + "\\Expressions\\";

                return saveDir;
            }
        }


        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            frmFunctions frm = new frmFunctions();
            frm.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            
            Expression exp = this.tabControl1.SelectedTab.Controls[0] as Expression;
            RuleGroup grp = this.tabControl1.SelectedTab.Controls[0] as RuleGroup;

            saveFileDialog1.InitialDirectory = ExpressionDirectory;            
            saveFileDialog1.FileName = "";

            if (exp != null)
            {
                if (exp.Token == null)
                {
                    MessageBox.Show("You must parse the expression before you can save.");
                    return;
                }

                saveFileDialog1.Filter = "Rule File (*.rule)|*.rule";

                DialogResult result = saveFileDialog1.ShowDialog();

                if (result == DialogResult.OK)
                {
                    string ErrorMsg = "";

                    if (exp.Token.Save(saveFileDialog1.FileName, out ErrorMsg) == false)
                    {
                        MessageBox.Show(ErrorMsg, "Save Rule", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                saveFileDialog1.Filter = "Rule Group File (*.group)|*.group";

                DialogResult result = saveFileDialog1.ShowDialog();

                if (result == DialogResult.OK)
                {
                    string ErrorMsg = "";

                    if (grp.Save(saveFileDialog1.FileName, out ErrorMsg) == false)
                    {
                        MessageBox.Show(ErrorMsg, "Save Rule", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {

            Expression exp = this.tabControl1.SelectedTab.Controls[0] as Expression;
            RuleGroup group = this.tabControl1.SelectedTab.Controls[0] as RuleGroup;

            openFileDialog1.InitialDirectory = ExpressionDirectory;            
            openFileDialog1.FileName = "";

            if (exp != null)
            {
                openFileDialog1.Filter = "Rule File (*.rule)|*.rule";
                openFileDialog1.Multiselect = false;

                DialogResult result = openFileDialog1.ShowDialog();

                string openData = "";

                if (result == DialogResult.OK)
                {
                    try
                    {

                        string ErrorMsg = "";
                        System.IO.FileInfo file = new System.IO.FileInfo(openFileDialog1.FileName);

                        try
                        {
                            exp.Token = new EvaluationEngine.Parser.Token(file);
                        }
                        catch (Exception err)
                        {
                            MessageBox.Show(err.Message, "Open Rule", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }
                    catch
                    {
                    }
                }
            }
            else if (group != null)
            {
                //openFileDialog1.Filter = "Group Text File (*.group.txt)|*.group.txt|Rule Text File (*.rule.txt)|*.rule.txt|Text File (*.txt)|*.txt";
                openFileDialog1.Filter = "Rule Group File, Rule File (*.group; *.rule)|*.group;*.rule";

                openFileDialog1.Multiselect = true;

                DialogResult result = openFileDialog1.ShowDialog();

                if (result == DialogResult.OK)
                {
                    // look at the first file
                    string firstFile = openFileDialog1.FileNames[0];

                    if (firstFile.EndsWith("group") == true)
                    {
                        string ErrorMsg = "";
                        if (group.Load(firstFile, out ErrorMsg) == false)
                        {
                            MessageBox.Show(ErrorMsg, "Open Group", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < openFileDialog1.FileNames.Length; i++)
                        {
                            group.AddFile(openFileDialog1.FileNames[i]);
                        }
                    }
                }

            }
        }      

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabNew)
            {
                switch (toolStripSplitButton1.Text)
                {
                    case "Rule":
                        CreateRule();
                        break;

                    case "Rule Group":
                        CreateRuleGroup();
                        break;
                }
                
            }
        }

        private void toolCloseTab_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex != tabControl1.TabPages.Count - 1)
            {
                tabControl1.TabPages.RemoveAt(tabControl1.SelectedIndex);
            }
        }


        private void CreateRule()
        {
            TabPage page = new TabPage();
            page.BackColor = SystemColors.ControlLightLight;
            page.Text = "Rule " + tabControl1.TabPages.Count.ToString();

            Expression exp = new Expression();
            exp.Dock = DockStyle.Fill;

            // add the event handlers
            exp.UpdateStatus += new UpdateStatusDelegate(UpdateStatusDelegate_Handler);
            exp.DisplayError += new DisplayErrorDelegate(DisplayErrorDelegate_Handler);
            exp.Timings += new TimingsDelegate(TimingsDelegate_Handler);

            // Set the colors that will be used.                
            exp.syntaxRichTextBox1.Settings.KeywordColor = Color.Blue;
            exp.syntaxRichTextBox1.Settings.CommentColor = Color.Green;
            exp.syntaxRichTextBox1.Settings.StringColor = Color.Maroon;
            exp.syntaxRichTextBox1.Settings.IntegerColor = Color.Gray;

            // Let's not process strings and integers.
            exp.syntaxRichTextBox1.Settings.EnableStrings = true;
            exp.syntaxRichTextBox1.Settings.EnableIntegers = true;

            // Let's make the settings we just set valid by compiling
            // the keywords to a regular expression.            

            for (int i = 0; i < EvaluationEngine.Support.DataTypeCheck.OperandFunctions.Length; i++)
            {
                exp.syntaxRichTextBox1.Settings.Keywords.Add(EvaluationEngine.Support.DataTypeCheck.OperandFunctions[i]);
            }

            exp.syntaxRichTextBox1.CompileKeywords();


            page.Controls.Add(exp);

            tabControl1.TabPages.Insert(tabControl1.TabPages.Count - 1, page);



            tabControl1.SelectedTab = page;

        }

        public void UpdateStatusDelegate_Handler(string Status, System.Drawing.Color BackColor)
        {
            this.statusError.Text = Status;
            this.statusError.BackColor = BackColor;
            Application.DoEvents();
        }

        public void DisplayErrorDelegate_Handler(string ErrorMsg)
        {
            this.statusError.Text = ErrorMsg;
            this.statusError.BackColor = Color.Red;
            Application.DoEvents();
        }

        public void TimingsDelegate_Handler(double TokenParseTime, double TotalTimeMS, int LoopCount, double TotalSeconds, double MIPS, double MIPM)
        {
            this.statusTokenParser.Text = "Token Parser: " + TokenParseTime.ToString("#,###.#####") + " ms";

            this.statusEvaluationTime.Text = "Evaluation Time: " + TotalTimeMS.ToString("#,###.#####") + " ms";
            this.statusEvaluationTimeSecs.Text = "Evaluation Time: " + TotalSeconds.ToString("#,###.#####") + " secs";

            this.statusMIPS.Text = MIPS.ToString("#,###.#####") + " mips";
            this.statusMIPM.Text = MIPM.ToString("#,###.#####") + " mipm";
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Expression exp = this.tabControl1.SelectedTab.Controls[0] as Expression;
            RuleGroup grp = this.tabControl1.SelectedTab.Controls[0] as RuleGroup;

            if (exp != null)
                exp.CreateTokens();
            else
                grp.DoEvaluation();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not implemented");
        }

        private void butRule_Click(object sender, EventArgs e)
        {
            toolStripSplitButton1.Text = butRule.Text;
            toolStripSplitButton1.Image = butRule.Image;
            CreateRule();

        }

        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e)
        {
            switch (toolStripSplitButton1.Text)
            {
                case "Rule":
                    CreateRule();
                    break;

                case "Rule Group":
                    CreateRuleGroup();
                    break;
            }

        }

        private void butRuleGroup_Click(object sender, EventArgs e)
        {
            toolStripSplitButton1.Text = butRuleGroup.Text;
            toolStripSplitButton1.Image = butRuleGroup.Image;
            CreateRuleGroup();
        }


        private void CreateRuleGroup()
        {
            TabPage page = new TabPage();
            page.BackColor = SystemColors.ControlLightLight;
            page.Text = "Group " + tabControl1.TabPages.Count.ToString();

            RuleGroup grp = new RuleGroup();
            grp.Dock = DockStyle.Fill;

            page.Controls.Add(grp);

            tabControl1.TabPages.Insert(tabControl1.TabPages.Count - 1, page);

            tabControl1.SelectedTab = page;

        }

    }
}