using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RulesCalculator
{
    public partial class frmListItem : Form
    {
        public frmListItem()
        {
            InitializeComponent();
        }

        private void butOk_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(this.txtItem.Text) == true)
            {
                MessageBox.Show("Please enter in a vlaue for the list item.", "List Item", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            this.DialogResult = DialogResult.OK;
        }
    }
}