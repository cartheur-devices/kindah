using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RulesCalculator
{
    public partial class frmFunctions : Form
    {
        public frmFunctions()
        {
            InitializeComponent();
        }

        private void frmFunctions_Load(object sender, EventArgs e)
        {
            string[] opFunctions = EvaluationEngine.Support.DataTypeCheck.OperandFunctions;
            Array.Sort(opFunctions);

            listBox1.DataSource = opFunctions;
            
            this.listBox1.SelectedIndex = 0;
            listBox1_SelectedIndexChanged(sender, e);
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string function = this.listBox1.SelectedItem.ToString();

            grpFunction.Text = function;


            string syntax = "";
            string description = "";
            string example = "";

            EvaluationEngine.Support.DataTypeCheck.FunctionDescription(function, out syntax, out description, out example);

            this.lblSyntax.Text = syntax;
            this.lblDescription.Text = description;
            this.lblExample.Text = example;

        }
    }
}