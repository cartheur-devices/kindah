using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RulesCalculator
{
    public partial class frmVariable : Form
    {
        private EvaluationEngine.Parser.Variable var;

        private EvaluationEngine.Parser.Variable cloneVar;

        public frmVariable()
        {
            InitializeComponent();
        }


        public EvaluationEngine.Parser.Variable Variable
        {
            get
            {
                return var;
            }
            set
            {
                var = value;
                //cloneVar = var.Clone();

                this.lblName.Text = var.VariableName;

                radioButton1.Checked = true;
                this.txtSingle.Text = var.VariableValue;

                /*
                switch (var.ValueType)
                {
                    case EvaluationEngine.Parser.VarValueType.Value_Single:
                        radioButton1.Checked = true;
                        this.txtSingle.Text = var.VariableValue;
                        break;

                    case EvaluationEngine.Parser.VarValueType.Value_RandomInt:
                        radioButton2.Checked = true;
                        this.txtFirst.Text = var.LowerIntValue.ToString();
                        this.txtLast.Text = var.UpperIntValue.ToString();
                        break;

                    case EvaluationEngine.Parser.VarValueType.Value_RandomList:
                        radioButton3.Checked = true;

                        for (int i = 0; i < var.ListItemCount; i++) lstVariables.Items.Add(var.ListItem(i));

                        break;
                }
                */
                
            }
        }

        private void butOk_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                if (String.IsNullOrEmpty(this.txtSingle.Text) == true)
                {
                    MessageBox.Show("Please enter in the single value for the variable.", "Variable Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtSingle.Focus();
                    return;
                }

                //var.ValueType = EvaluationEngine.Parser.VarValueType.Value_Single;
                var.VariableValue = this.txtSingle.Text;

            }
            else if (radioButton2.Checked == true)
            {
                /*
                if (String.IsNullOrEmpty(this.txtFirst.Text) == true)
                {
                    MessageBox.Show("Please enter a starting point for the first random integer.", "Variable Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtFirst.Focus();
                    return;
                }

                if (String.IsNullOrEmpty(this.txtLast.Text) == true)
                {
                    MessageBox.Show("Please enter in the upper value of the random integer.", "Variable Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtLast.Focus();
                    return;
                }

                int lowerInt = 0;
                int upperInt = 0;
                try
                {
                    lowerInt = Convert.ToInt32(txtFirst.Text);
                    upperInt = Convert.ToInt32(txtLast.Text);
                }
                catch
                {
                    MessageBox.Show("Please enter a numberic value for the integer range.", "Variable Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtLast.Focus();
                    return;
                }

                if (lowerInt >= upperInt)
                {
                    MessageBox.Show("The lowe integer value must be less than the upper value.", "Variable Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtLast.Focus();
                    return;
                }

                var.ValueType = EvaluationEngine.Parser.VarValueType.Value_RandomInt;
                var.LowerIntValue = lowerInt;
                var.UpperIntValue = upperInt;
                */

            }
            else if (radioButton3.Checked == true)
            {
                /*
                if (this.lstVariables.Items.Count == 0)
                {
                    MessageBox.Show("Please enter one or more items into the random list.", "Variable Value", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                var.ValueType = EvaluationEngine.Parser.VarValueType.Value_RandomList;

                for (int i = 0; i < lstVariables.Items.Count; i++) var.AddListItem(lstVariables.Items[i].ToString());
                */
            }

            this.DialogResult = DialogResult.OK;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                txtSingle.Enabled = true;
                txtFirst.Enabled = false;
                txtLast.Enabled = false;
                lstVariables.Enabled = false;
                butAdd.Enabled = false;
                butRemove.Enabled = false;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                txtSingle.Enabled = false;
                txtFirst.Enabled = true;
                txtLast.Enabled = true;
                lstVariables.Enabled = false;
                butAdd.Enabled = false;
                butRemove.Enabled = false;
            }

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)            {
                txtSingle.Enabled = false;
                txtFirst.Enabled = false;
                txtLast.Enabled = false;
                lstVariables.Enabled = true;
                butAdd.Enabled = true;
                butRemove.Enabled = true;
            }

        }

        private void butCancel_Click(object sender, EventArgs e)
        {
            //var.Copy(cloneVar);
        }

        private void butAdd_Click(object sender, EventArgs e)
        {
            frmListItem frm = new frmListItem();

            DialogResult result = frm.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                lstVariables.Items.Add(frm.txtItem.Text);
                lstVariables.SelectedIndex = lstVariables.Items.Count - 1;
            }

            frm.Close();
        }

        private void butRemove_Click(object sender, EventArgs e)
        {
            if (lstVariables.SelectedIndex < 0) return;

            this.lstVariables.Items.RemoveAt(this.lstVariables.SelectedIndex);

            if (lstVariables.Items.Count > 0)
                lstVariables.SelectedIndex = lstVariables.Items.Count - 1;
        }

        private void frmVariable_Load(object sender, EventArgs e)
        {

        }

    }
}