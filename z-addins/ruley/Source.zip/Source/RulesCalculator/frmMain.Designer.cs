namespace RulesCalculator
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabNew = new System.Windows.Forms.TabPage();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addParenthesisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeParenthesisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.removeFunctionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addFunctionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.statusTokenParser = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusEvaluationTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusEvaluationTimeSecs = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusMIPS = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusMIPM = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusError = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.butRule = new System.Windows.Forms.ToolStripMenuItem();
            this.butRuleGroup = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolCloseTab = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.tabControl1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabNew);
            this.tabControl1.Location = new System.Drawing.Point(12, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1009, 508);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabNew
            // 
            this.tabNew.Location = new System.Drawing.Point(4, 22);
            this.tabNew.Name = "tabNew";
            this.tabNew.Padding = new System.Windows.Forms.Padding(3);
            this.tabNew.Size = new System.Drawing.Size(1001, 482);
            this.tabNew.TabIndex = 1;
            this.tabNew.Text = "<New Tab>";
            this.tabNew.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addParenthesisToolStripMenuItem,
            this.removeParenthesisToolStripMenuItem,
            this.toolStripMenuItem1,
            this.removeFunctionsToolStripMenuItem,
            this.addFunctionToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(184, 98);
            // 
            // addParenthesisToolStripMenuItem
            // 
            this.addParenthesisToolStripMenuItem.Name = "addParenthesisToolStripMenuItem";
            this.addParenthesisToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.addParenthesisToolStripMenuItem.Text = "Add Parenthesis";
            // 
            // removeParenthesisToolStripMenuItem
            // 
            this.removeParenthesisToolStripMenuItem.Name = "removeParenthesisToolStripMenuItem";
            this.removeParenthesisToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.removeParenthesisToolStripMenuItem.Text = "Remove Parenthesis";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(180, 6);
            // 
            // removeFunctionsToolStripMenuItem
            // 
            this.removeFunctionsToolStripMenuItem.Name = "removeFunctionsToolStripMenuItem";
            this.removeFunctionsToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.removeFunctionsToolStripMenuItem.Text = "Remove Functions";
            // 
            // addFunctionToolStripMenuItem
            // 
            this.addFunctionToolStripMenuItem.Name = "addFunctionToolStripMenuItem";
            this.addFunctionToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.addFunctionToolStripMenuItem.Text = "Add Function";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusTokenParser,
            this.statusEvaluationTime,
            this.statusEvaluationTimeSecs,
            this.statusMIPS,
            this.statusMIPM,
            this.statusError});
            this.statusStrip1.Location = new System.Drawing.Point(0, 549);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1033, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // statusTokenParser
            // 
            this.statusTokenParser.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.statusTokenParser.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.statusTokenParser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.statusTokenParser.Name = "statusTokenParser";
            this.statusTokenParser.Size = new System.Drawing.Size(103, 17);
            this.statusTokenParser.Text = "Token Parser: 0 ms";
            // 
            // statusEvaluationTime
            // 
            this.statusEvaluationTime.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.statusEvaluationTime.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.statusEvaluationTime.Name = "statusEvaluationTime";
            this.statusEvaluationTime.Size = new System.Drawing.Size(115, 17);
            this.statusEvaluationTime.Text = "Evaluation Time: 0 ms";
            // 
            // statusEvaluationTimeSecs
            // 
            this.statusEvaluationTimeSecs.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.statusEvaluationTimeSecs.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.statusEvaluationTimeSecs.Name = "statusEvaluationTimeSecs";
            this.statusEvaluationTimeSecs.Size = new System.Drawing.Size(123, 17);
            this.statusEvaluationTimeSecs.Text = "Evaluation Time: 0 secs";
            // 
            // statusMIPS
            // 
            this.statusMIPS.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.statusMIPS.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.statusMIPS.Name = "statusMIPS";
            this.statusMIPS.Size = new System.Drawing.Size(44, 17);
            this.statusMIPS.Text = "0 MIPS";
            this.statusMIPS.ToolTipText = "Millions of Instructions per Second";
            // 
            // statusMIPM
            // 
            this.statusMIPM.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.statusMIPM.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.statusMIPM.Name = "statusMIPM";
            this.statusMIPM.Size = new System.Drawing.Size(46, 17);
            this.statusMIPM.Text = "0 MIPM";
            this.statusMIPM.ToolTipText = "Million of Instructions per Minute";
            // 
            // statusError
            // 
            this.statusError.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.statusError.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.statusError.Name = "statusError";
            this.statusError.Size = new System.Drawing.Size(587, 17);
            this.statusError.Spring = true;
            this.statusError.Text = "Ready...";
            this.statusError.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton1,
            this.toolStripSeparator6,
            this.toolStripButton1,
            this.toolStripSeparator1,
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripButton3,
            this.toolStripSeparator3,
            this.toolStripButton4,
            this.toolStripSeparator4,
            this.toolCloseTab,
            this.toolStripSeparator5,
            this.toolStripButton5});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1033, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.butRule,
            this.butRuleGroup});
            this.toolStripSplitButton1.Image = global::RulesCalculator.Properties.Resources.page_flash;
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(60, 22);
            this.toolStripSplitButton1.Text = "Rule";
            this.toolStripSplitButton1.ButtonClick += new System.EventHandler(this.toolStripSplitButton1_ButtonClick);
            // 
            // butRule
            // 
            this.butRule.Image = global::RulesCalculator.Properties.Resources.page_flash;
            this.butRule.Name = "butRule";
            this.butRule.Size = new System.Drawing.Size(152, 22);
            this.butRule.Text = "Rule";
            this.butRule.Click += new System.EventHandler(this.butRule_Click);
            // 
            // butRuleGroup
            // 
            this.butRuleGroup.Image = global::RulesCalculator.Properties.Resources.page_component;
            this.butRuleGroup.Name = "butRuleGroup";
            this.butRuleGroup.Size = new System.Drawing.Size(152, 22);
            this.butRuleGroup.Text = "Rule Group";
            this.butRuleGroup.Click += new System.EventHandler(this.butRuleGroup_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(51, 22);
            this.toolStripButton1.Text = "Save";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(53, 22);
            this.toolStripButton2.Text = "Open";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(55, 22);
            this.toolStripButton3.Text = "Verify";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(73, 22);
            this.toolStripButton4.Text = "Functions";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolCloseTab
            // 
            this.toolCloseTab.Image = ((System.Drawing.Image)(resources.GetObject("toolCloseTab.Image")));
            this.toolCloseTab.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolCloseTab.Name = "toolCloseTab";
            this.toolCloseTab.Size = new System.Drawing.Size(74, 22);
            this.toolCloseTab.Text = "Close Tab";
            this.toolCloseTab.Click += new System.EventHandler(this.toolCloseTab_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(54, 22);
            this.toolStripButton5.Text = "Parse";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 571);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rules Engine Calculator";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.tabControl1.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabNew;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addParenthesisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeParenthesisToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem removeFunctionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addFunctionToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripStatusLabel statusTokenParser;
        private System.Windows.Forms.ToolStripStatusLabel statusEvaluationTime;
        private System.Windows.Forms.ToolStripStatusLabel statusEvaluationTimeSecs;
        private System.Windows.Forms.ToolStripStatusLabel statusMIPS;
        private System.Windows.Forms.ToolStripStatusLabel statusMIPM;
        private System.Windows.Forms.ToolStripStatusLabel statusError;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolCloseTab;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem butRule;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem butRuleGroup;
    }
}

